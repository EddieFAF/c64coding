This is a Test setup for Sublime and ACME Assembler.

All files needed to 

F1 	Run Makefile
F3	Build
F5	Build + Run


Just copy directory for your project.





Fix/Onslaught - 2014