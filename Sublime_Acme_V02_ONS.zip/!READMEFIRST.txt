------------------------------------------------
ACME Support for Sublime Editor by Fix/Onslaught


Date:		2014-10-27
Version:	0.2
OS:		Windows


Based on Kickassembler for Sublime from Swoffa.

-------------------------------------------------

Installation:
Install Acme.package with Package Control in Sublime.

-------------------------------------------------

Commands:

F1	Run Makefile script in Source Dir.	
F3	Compile Source
F5	Compile and Run Vice

-------------------------------------------------

Makefile script:

It's just a .bat file, and you can edit it as you need.

-------------------------------------------------

Paths/Files:

Sorurcefile:	C:\C64\Source
Vice		C:\C64\Emulators\Vice2.4
Acme		C:\C64\Assemblers\ACME
1541		C:\C64\Emulators\Vice2.4

-------------------------------------------------

Todo:		Add full support for Acme syntax.
		Clean up old kickassembler stuff
		Add OS X/Linux support


-------------------------------------------------
Version:

0.1	First release
0.2	Added better Color Themes (add them manually)
	Added more ACME Assembeler syntaxes
	


-------------------------------------------------

Greetings:

All members of Onslaught, Ron/SOS and all other nice people out there.

-------------------------------------------------

Updates:

www.csdb.dk